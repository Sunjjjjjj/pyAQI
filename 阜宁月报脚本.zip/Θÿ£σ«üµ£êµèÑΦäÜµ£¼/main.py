#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Sep 19 17:39:54 2022

@author: sunji
"""

from functions import *
generate_report()

